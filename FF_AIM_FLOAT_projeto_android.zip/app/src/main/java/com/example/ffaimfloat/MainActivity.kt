package com.example.ffaimfloat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        val title = TextView(this).apply {
            text = "FF AIM FLOAT"
            textSize = 28f
            setTextColor(Color.rgb(255, 70, 70))
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Painel flutuante educativo\\nSensibilidade • HUD • Treino • Segurança\\n\\nNão altera nem controla o Free Fire."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(24))
        }
        val permission = Button(this).apply {
            text = "1. Autorizar janela flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    text = "Permissão autorizada"
                }
            }
        }
        val launch = Button(this).apply {
            text = "2. Abrir painel flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                    else startService(intent)
                    finish()
                } else {
                    text = "Autorize a janela flutuante primeiro"
                }
            }
        }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(desc)
        root.addView(permission)
        root.addView(launch)
        setContentView(root)
    }
}
