package com.example.ffaimfloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private val channelId = "ff_aim_float"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "FF AIM FLOAT", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        return builder.setContentTitle("FF AIM FLOAT ativo")
            .setContentText("Painel educativo flutuante em execução")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
    }

    private fun label(text: String, size: Float = 14f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10))
            setBackgroundColor(Color.rgb(27, 27, 36))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(130, 20, 30))
        }
        val title = label("FF AIM FLOAT  •  arraste aqui", 14f)
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(42)))
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun showTab(which: String) {
            content.removeAllViews()
            when (which) {
                "MIRA" -> {
                    content.addView(label("Ajustes manuais (não aplicados ao jogo)", 12f))
                    listOf("Sensibilidade geral", "Red Dot", "Mira 2x", "Mira 4x", "Tamanho do botão de tiro").forEach { name ->
                        content.addView(label(name))
                        content.addView(SeekBar(this).apply { max = 200; progress = 90 })
                    }
                }
                "TREINO" -> {
                    content.addView(label("Rotina de treino • 10 minutos", 16f))
                    content.addView(label("2 min: acompanhar alvos\\n3 min: puxada curta\\n3 min: precisão\\n2 min: controle de recuo"))
                    content.addView(label("Pratique no campo de treinamento do jogo."))
                }
                else -> {
                    content.addView(label("Segurança da conta", 16f))
                    content.addView(label("• Evite APKs modificados\\n• Não use scripts ou macros\\n• Não compartilhe sua senha\\n• Não instale ferramentas que alterem o jogo"))
                }
            }
        }
        listOf("MIRA", "TREINO", "SEGURANÇA").forEach { name ->
            tabs.addView(Button(this).apply {
                text = name
                textSize = 10f
                setOnClickListener { showTab(name) }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(tabs)
        root.addView(content)
        showTab("MIRA")

        val params = WindowManager.LayoutParams(
            dp(290), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(100)
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
