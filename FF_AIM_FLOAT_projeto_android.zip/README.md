# FF AIM FLOAT

Aplicativo Android educativo com painel flutuante independente.

## Gerar o APK pelo celular usando GitHub

1. Crie um repositório novo no GitHub, por exemplo `ff-aim-float`.
2. Extraia este ZIP no celular.
3. Envie todos os arquivos e pastas para a raiz do repositório (incluindo `.github`).
4. Abra a aba **Actions** no GitHub.
5. Selecione **Build Android APK** e toque em **Run workflow**. Também compila automaticamente após enviar arquivos para a branch `main`.
6. Quando terminar, abra a execução concluída e baixe o artefato `FF-AIM-FLOAT-debug`.
7. Extraia o ZIP do artefato e instale `app-debug.apk`. O Android pode pedir autorização para instalar apps dessa origem.
8. Abra FF AIM FLOAT, autorize **Exibir sobre outros apps** e toque em **Abrir painel flutuante**.

## Observações

- O painel não controla, modifica nem injeta código no Free Fire.
- Os controles de sensibilidade são apenas referências visuais; aplique valores manualmente nas configurações do jogo.
- O APK de debug é para teste. Não é publicado na Play Store nem assinado como versão de distribuição.
- Se o GitHub Actions falhar, confira os logs da execução e abra uma issue com a mensagem de erro.
