package com.painel.gamerff

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(28, 28, 34))
        }
        val header = TextView(this).apply {
            text = "🔥 PAINEL GAMER  [arraste aqui]"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        }
        header.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(panel, params)
                        return true
                    }
                }
                return false
            }
        })
        container.addView(header)
        addButton(container, "PERFIL: EQUILIBRADO") {
            showMessage(container, "Perfil visual selecionado: Equilibrado")
        }
        addButton(container, "PERFIL: PRECISÃO") {
            showMessage(container, "Perfil visual selecionado: Precisão")
        }
        addButton(container, "DICA DE HUD") {
            showMessage(container, "Ajuste o HUD nas configurações oficiais do Free Fire.")
        }
        addButton(container, "FECHAR PAINEL") { stopSelf() }

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 180
        }
        panel = container
        wm.addView(container, params)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 11f
            setOnClickListener { action() }
        }
        parent.addView(button)
    }

    private fun showMessage(parent: LinearLayout, message: String) {
        val notice = TextView(this).apply {
            text = message
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(4, 6, 4, 6)
        }
        if (parent.childCount > 1) parent.removeViewAt(parent.childCount - 1)
        parent.addView(notice, 1)
    }

    override fun onDestroy() {
        panel?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
